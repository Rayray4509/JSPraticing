class timer {
    constructor(){
        this.count = 0;
        
    }
}
let bullet = {
    position:[],
    el:false
}
function creatBullet(){
    div = document.createElement(div);
    document
}
function moveBulletPosition(){
    pla

    
}